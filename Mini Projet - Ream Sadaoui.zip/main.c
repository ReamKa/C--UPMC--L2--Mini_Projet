#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int alloue_tableau(int **T, int n){
  *T = (int*)malloc(n*sizeof(int));
    if(T == NULL){
        return 1;
    }
    return 0;
}

void desallouer_tableau(int **tab){
    free(*tab);
}

void afficher_tableau(int **tableau, int taille){
    int x;
    for (x=0;x<taille;x++){
            printf("%d", *tableau[x]);
    }
}

void remplir_tableau (int**tableau, int taille, int v){
    int i = 0;
    for (i=0; i<taille;i++){
            (*tableau[i])=rand()%v;
    }
    }

int n_au_carre (int **tableau, int x){
    int a,b;
    int c = 0;
    for (a = 0; a < x;a++){
            for (b =0; b < x; b++){
                c += ((*tableau)[a] - (*tableau)[b]) * ((*tableau)[a] - (*tableau)[b]);
            }
            }
            return c;
            }

int meilleure_complexite(int **tableau, int x){
    int a;
    int resultat = 0;
    int r1 = 0;
    int r2 = 0;
    for (a = 0; a < x; a ++){
            r1 += (*tableau)[a];
            r2 += ((*tableau)[a] * ((*tableau)[a]));
    }
    resultat = 2 * (x*r2-(r1*r1));
    return resultat;
    }

int main(){
  srand(time(NULL));
  clock_t t_i;
  clock_t t_f;
  double t_cpu;
  int n=0;
  FILE *f=NULL;
  f=fopen("sortie_vitesse.txt","w");
  for(n=0;n<1000;n++){
    int *tab;
    alloue_tableau(&tab,n);
    remplir_tableau(&tab,n,2);

    t_i=clock();
    int resultat1=n_au_carre(&tab,n);
    t_f=clock(); //fin
    t_cpu=((double)(t_f-t_i))/CLOCKS_PER_SEC;
    fprintf(f,"%d %f",n,t_cpu);

    t_i=clock();
    int resultat2=meilleure_complexite(&tab,n);
    t_f=clock();
    t_cpu=((double)(t_f-t_i))/CLOCKS_PER_SEC;
    fprintf(f," %f\n",t_cpu);

    //printf("%d %d \n",resultat1,resultat2); //permet de tester que les algorithmes retournent bien la m�me valeur
    desallouer_tableau(&tab);
  }
  fclose(f);
}
